### Hexlet tests and linter status:
[![Actions Status](https://github.com/Johnny32id/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Johnny32id/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/28b087f76e9bca034a52/maintainability)](https://codeclimate.com/github/Johnny32id/python-project-49/maintainability)

**Asciinema:**
* brain-even (https://asciinema.org/a/N4p5D1BOIlI7Rnx47MdqRmqts)
* brain-calc (https://asciinema.org/a/C0EYUG2pjOUin7p8ZolaDzi6e)
* brain-gcd (https://asciinema.org/a/tfs8teIYTJ7AyfbbjuwmjjKOy)